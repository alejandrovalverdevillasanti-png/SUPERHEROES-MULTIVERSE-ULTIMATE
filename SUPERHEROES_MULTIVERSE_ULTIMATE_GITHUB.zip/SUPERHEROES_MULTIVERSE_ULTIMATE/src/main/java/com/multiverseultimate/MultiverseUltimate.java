package com.multiverseultimate;

import com.mojang.logging.LogUtils;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

@Mod(MultiverseUltimate.MOD_ID)
public class MultiverseUltimate {
    public static final String MOD_ID = "multiverseultimate";
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    // First playable project milestone: the prototype Omnitrix item.
    public static final RegistryObject<Item> OMNITRIX = ITEMS.register("omnitrix",
            () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> COSMIC_ENERGY_CELL = ITEMS.register("cosmic_energy_cell",
            () -> new Item(new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));

    public MultiverseUltimate() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modBus);
        modBus.addListener(this::addCreativeItems);
        LOGGER.info("SUPERHEROES: MULTIVERSE ULTIMATE initialized.");
    }

    private void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(OMNITRIX);
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(COSMIC_ENERGY_CELL);
        }
    }
}
