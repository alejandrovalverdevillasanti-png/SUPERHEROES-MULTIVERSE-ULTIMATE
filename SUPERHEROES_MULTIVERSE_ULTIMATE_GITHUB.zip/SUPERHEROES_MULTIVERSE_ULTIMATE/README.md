# SUPERHEROES: MULTIVERSE ULTIMATE — Forge 1.20.1

Starter source project based on the supplied Forge MDK.

- Minecraft: 1.20.1
- Forge: 47.2.0
- Java: 17
- Mod ID: `multiverseultimate`
- Version: `0.1.0`

## Current implemented milestone

- Forge mod entry point and item registry.
- Prototype Omnitrix item (`multiverseultimate:omnitrix`).
- Cosmic Energy Cell item (`multiverseultimate:cosmic_energy_cell`).
- Item models and original placeholder icons.

The Omnitrix is currently a registered prototype item only. Scanning, alien transformations, combat, characters, dimensions, and abilities are planned modules and are **not implemented yet**.

## Build on GitHub

1. Create a new GitHub repository and upload the **contents** of this folder (not the enclosing ZIP).
2. Open **Actions** and allow workflows if GitHub asks.
3. The workflow `Build Forge Mod` runs `./gradlew build` with Java 17.
4. Open the completed workflow run and download the `mod-jar` artifact. The JAR is under `build/libs/`.

## Build locally

With Java 17 installed, run:

- Windows: `gradlew.bat build`
- Linux/macOS: `./gradlew build`

Output: `build/libs/multiverseultimate-0.1.0.jar` (plus any development/source jars produced by Gradle).

## Compatibility note

The project targets Forge 1.20.1. Android/Zalith compatibility must be tested with the exact mod list and device; it is not guaranteed merely by compiling successfully.
